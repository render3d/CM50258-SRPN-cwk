# Click run above to run the legacy SRPN code

chmod +x ./srpn/srpn
echo "You can now start interacting with the SRPN calculator"
./srpn/srpn

# Once you have clicked run try typing in the example input 
# and observe the output
# 
# For example, try
#
# 10 
# 2
# +
# =